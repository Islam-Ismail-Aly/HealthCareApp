package com.example.quiz;

public class Database {
    Integer[] flags={
            R.drawable.upone,
            R.drawable.downone,
            R.drawable.leftone,
            R.drawable.rightone,
            R.drawable.uptwo,
            R.drawable.downtwo,
            R.drawable.lefttwo,
            R.drawable.righttwo,
            R.drawable.upthree,
            R.drawable.downthree,
            R.drawable.leftthree,
            R.drawable.rightthree,
            R.drawable.upfour,
            R.drawable.downfour,
            R.drawable.leftfour,
            R.drawable.rightfour
    };
    String[] answers={
            "Up",
            "Down",
            "Left",
            "Right",
            "Up",
            "Down",
            "Left",
            "Right",
            "Up",
            "Down",
            "Left",
            "Right",
            "Up",
            "Down",
            "Left",
            "Right",
    };

}
