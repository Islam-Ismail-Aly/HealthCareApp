package com.example.hesham.healthycare;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Hesham on 30-May-19.
 */

public class Aboutus extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutus);
    }
}
