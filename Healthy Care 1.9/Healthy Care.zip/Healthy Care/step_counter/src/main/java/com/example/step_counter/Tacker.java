package com.example.step_counter;

/**
 * Created by Hesham on 26-May-19.
 */

class Tacker {

    private int value;

    Tacker(int initialValue) {
        setValue(initialValue);
    }

    void setValue(int value) {
        this.value = value;
    }

    int getValue() {
        return value;
    }

    void reset() {
        this.value = 0;
    }

    void increment() {
        value = value + 1;
    }
}
